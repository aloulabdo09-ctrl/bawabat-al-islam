import 'package:flutter/material.dart';

void main() => runApp(const BawabatAlIslamApp());

const deepGreen = Color(0xFF082C24);
const green = Color(0xFF124638);
const gold = Color(0xFFD6B56D);
const cream = Color(0xFFF7F4EC);

class BawabatAlIslamApp extends StatelessWidget {
  const BawabatAlIslamApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'بوابة الإسلام',
      theme: ThemeData(
        useMaterial3: true,
        scaffoldBackgroundColor: cream,
        colorScheme: ColorScheme.fromSeed(seedColor: green, primary: green),
        fontFamily: 'Arial',
        appBarTheme: const AppBarTheme(
          backgroundColor: deepGreen,
          foregroundColor: Colors.white,
          centerTitle: true,
          elevation: 0,
        ),
      ),
      home: const MainShell(),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int selected = 0;
  final pages = const [
    HomePage(),
    QuranPage(),
    LearnPage(),
    DawahPage(),
    MorePage(),
  ];

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        body: IndexedStack(index: selected, children: pages),
        bottomNavigationBar: NavigationBar(
          backgroundColor: Colors.white,
          indicatorColor: gold.withOpacity(.22),
          selectedIndex: selected,
          onDestinationSelected: (i) => setState(() => selected = i),
          destinations: const [
            NavigationDestination(icon: Icon(Icons.home_outlined), selectedIcon: Icon(Icons.home), label: 'الرئيسية'),
            NavigationDestination(icon: Icon(Icons.menu_book_outlined), selectedIcon: Icon(Icons.menu_book), label: 'القرآن'),
            NavigationDestination(icon: Icon(Icons.school_outlined), selectedIcon: Icon(Icons.school), label: 'تعلّم'),
            NavigationDestination(icon: Icon(Icons.public_outlined), selectedIcon: Icon(Icons.public), label: 'تعرّف'),
            NavigationDestination(icon: Icon(Icons.grid_view_outlined), selectedIcon: Icon(Icons.grid_view), label: 'المزيد'),
          ],
        ),
      ),
    );
  }
}

class HomePage extends StatelessWidget {
  const HomePage({super.key});

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      slivers: [
        SliverAppBar(
          pinned: true,
          expandedHeight: 250,
          title: const Text('بوابة الإسلام', style: TextStyle(fontWeight: FontWeight.bold)),
          flexibleSpace: FlexibleSpaceBar(
            background: Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  begin: Alignment.topRight, end: Alignment.bottomLeft,
                  colors: [deepGreen, green, Color(0xFF1B5945)],
                ),
              ),
              child: Stack(
                children: [
                  Positioned(left: -25, top: 25, child: Icon(Icons.mosque, size: 190, color: gold.withOpacity(.10))),
                  const Positioned(
                    right: 22, bottom: 28, left: 22,
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('نورٌ من الوحي', style: TextStyle(color: gold, fontSize: 14, fontWeight: FontWeight.w600)),
                        SizedBox(height: 8),
                        Text('تعرّف على الإسلام\nمن مصادره الأصيلة', style: TextStyle(color: Colors.white, fontSize: 25, height: 1.4, fontWeight: FontWeight.bold)),
                        SizedBox(height: 7),
                        Text('القرآن الكريم • السنة النبوية • العلم والدعوة', style: TextStyle(color: Colors.white70, fontSize: 12)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
        SliverToBoxAdapter(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text('ابدأ رحلتك', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: deepGreen)),
                const SizedBox(height: 12),
                GridView.count(
                  crossAxisCount: 2, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
                  mainAxisSpacing: 12, crossAxisSpacing: 12, childAspectRatio: 1.45,
                  children: const [
                    FeatureCard(icon: Icons.menu_book, title: 'القرآن الكريم', subtitle: 'تلاوة وتدبّر'),
                    FeatureCard(icon: Icons.auto_stories, title: 'السنة النبوية', subtitle: 'أحاديث وشروح'),
                    FeatureCard(icon: Icons.lightbulb_outline, title: 'العقيدة', subtitle: 'أصول الإيمان والتوحيد'),
                    FeatureCard(icon: Icons.forum_outlined, title: 'تعرّف على الإسلام', subtitle: 'إجابات للباحثين'),
                  ],
                ),
                const SizedBox(height: 22),
                const Text('رسالة اليوم', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: deepGreen)),
                const SizedBox(height: 10),
                Container(
                  width: double.infinity, padding: const EdgeInsets.all(18),
                  decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(18), border: Border.all(color: gold.withOpacity(.65))),
                  child: const Column(
                    children: [
                      Text('﴿ وَقُلْ رَبِّ زِدْنِي عِلْمًا ﴾', textAlign: TextAlign.center, style: TextStyle(fontSize: 23, height: 1.8, color: deepGreen, fontWeight: FontWeight.bold)),
                      SizedBox(height: 6),
                      Text('سورة طه، الآية 114', style: TextStyle(color: Colors.black54)),
                    ],
                  ),
                ),
                const SizedBox(height: 20),
                const Text('منهجنا', style: TextStyle(fontSize: 19, fontWeight: FontWeight.bold, color: deepGreen)),
                const SizedBox(height: 8),
                const Text('نعرض العلم مع توثيق مصادره، ونحرص على الرجوع إلى القرآن والسنة الصحيحة وفهم السلف الصالح، مع إحالة الفتاوى والنوازل إلى أهل العلم المؤهلين.', style: TextStyle(fontSize: 14, height: 1.8, color: Colors.black87)),
                const SizedBox(height: 24),
              ],
            ),
          ),
        ),
      ],
    );
  }
}

class FeatureCard extends StatelessWidget {
  final IconData icon;
  final String title;
  final String subtitle;
  const FeatureCard({super.key, required this.icon, required this.title, required this.subtitle});

  @override
  Widget build(BuildContext context) => Container(
    padding: const EdgeInsets.all(14),
    decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(17), boxShadow: [BoxShadow(color: Colors.black.withOpacity(.04), blurRadius: 10, offset: const Offset(0, 3))]),
    child: Column(crossAxisAlignment: CrossAxisAlignment.start, mainAxisAlignment: MainAxisAlignment.center, children: [
      Icon(icon, color: green, size: 27),
      const SizedBox(height: 8),
      Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: deepGreen, fontSize: 15)),
      const SizedBox(height: 3),
      Text(subtitle, style: const TextStyle(color: Colors.black54, fontSize: 11)),
    ]),
  );
}

class QuranPage extends StatelessWidget {
  const QuranPage({super.key});
  @override
  Widget build(BuildContext context) => SimplePage(
    title: 'القرآن الكريم',
    intro: 'اقرأ القرآن الكريم، وابحث عن السور والآيات، واختر لغة ترجمة المعاني.',
    children: const [
      InfoTile(icon: Icons.bookmark, title: 'متابعة القراءة', subtitle: 'ستظهر هنا آخر سورة وصلت إليها بعد إضافة ميزة الحفظ.'),
      InfoTile(icon: Icons.translate, title: 'ترجمة معاني القرآن', subtitle: 'العربية والإنجليزية والفرنسية ولغات أخرى — ستُربط بمصادر ترجمة موثوقة.'),
      InfoTile(icon: Icons.headphones, title: 'التلاوات الصوتية', subtitle: 'اختيار القارئ والاستماع دون اتصال عند توفير الملفات.'),
    ],
  );
}

class LearnPage extends StatelessWidget {
  const LearnPage({super.key});
  @override
  Widget build(BuildContext context) => SimplePage(
    title: 'تعلّم الدين',
    intro: 'مسارات مرتبة للمبتدئ والمتعلم، مع أدلة ومراجع لكل موضوع.',
    children: const [
      InfoTile(icon: Icons.account_balance, title: 'العقيدة والتوحيد', subtitle: 'أركان الإيمان، توحيد الله، وأصول الاعتقاد.'),
      InfoTile(icon: Icons.menu_book, title: 'الحديث والسنة', subtitle: 'مصادر الحديث، التخريج، وشرح النصوص.'),
      InfoTile(icon: Icons.mosque, title: 'الفقه والعبادات', subtitle: 'الطهارة والصلاة والصيام والزكاة والحج.'),
      InfoTile(icon: Icons.favorite_border, title: 'الأخلاق والآداب', subtitle: 'الأمانة والرحمة والعدل وحسن التعامل.'),
    ],
  );
}

class DawahPage extends StatelessWidget {
  const DawahPage({super.key});
  @override
  Widget build(BuildContext context) => SimplePage(
    title: 'تعرّف على الإسلام',
    intro: 'مساحة مفتوحة لكل من يريد أن يعرف الإسلام من مصادره، ويسأل دون حرج.',
    children: const [
      InfoTile(icon: Icons.help_outline, title: 'ما الإسلام؟', subtitle: 'تعريف مبسّط بالإسلام وأركانه ومعاني الاستسلام لله.'),
      InfoTile(icon: Icons.person_outline, title: 'من هو محمد ﷺ؟', subtitle: 'التعريف بالنبي ورسالته وسيرته.'),
      InfoTile(icon: Icons.auto_awesome, title: 'لماذا نؤمن بالقرآن؟', subtitle: 'التعريف بالقرآن ووحيه وحفظه ودلالاته.'),
      InfoTile(icon: Icons.question_answer_outlined, title: 'أسئلة وشبهات', subtitle: 'إجابات هادئة موثقة، مع ذكر المصادر وإحالة المسائل المتخصصة للمؤهلين.'),
      InfoTile(icon: Icons.volunteer_activism_outlined, title: 'أريد اعتناق الإسلام', subtitle: 'شرح الشهادتين ومعناهما والخطوات الأولى، دون اشتراط التسجيل.'),
    ],
  );
}

class MorePage extends StatelessWidget {
  const MorePage({super.key});
  @override
  Widget build(BuildContext context) => SimplePage(
    title: 'المزيد',
    intro: 'إعدادات وخدمات إضافية.',
    children: const [
      InfoTile(icon: Icons.language, title: 'اللغة', subtitle: 'سيُضاف اختيار اللغة وتغيير اتجاه العرض حسب اللغة.'),
      InfoTile(icon: Icons.access_time, title: 'مواقيت الصلاة', subtitle: 'تحديد المدينة أو الموقع بإذن المستخدم فقط.'),
      InfoTile(icon: Icons.favorite, title: 'المفضلة', subtitle: 'حفظ الآيات والأحاديث والمقالات.'),
      InfoTile(icon: Icons.info_outline, title: 'عن بوابة الإسلام', subtitle: 'مشروع تعليمي ودعوي مجاني، بمحتوى موثق ومراجع علمية.'),
    ],
  );
}

class SimplePage extends StatelessWidget {
  final String title, intro;
  final List<Widget> children;
  const SimplePage({super.key, required this.title, required this.intro, required this.children});
  @override
  Widget build(BuildContext context) => Scaffold(
    appBar: AppBar(title: Text(title)),
    body: ListView(padding: const EdgeInsets.all(16), children: [
      Text(intro, style: const TextStyle(fontSize: 15, height: 1.8, color: Colors.black87)),
      const SizedBox(height: 14),
      ...children,
    ]),
  );
}

class InfoTile extends StatelessWidget {
  final IconData icon;
  final String title, subtitle;
  const InfoTile({super.key, required this.icon, required this.title, required this.subtitle});
  @override
  Widget build(BuildContext context) => Card(
    color: Colors.white, elevation: 0, margin: const EdgeInsets.only(bottom: 10),
    shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(15), side: BorderSide(color: Colors.black.withOpacity(.05))),
    child: ListTile(
      contentPadding: const EdgeInsets.symmetric(horizontal: 15, vertical: 8),
      leading: CircleAvatar(backgroundColor: gold.withOpacity(.18), child: Icon(icon, color: green)),
      title: Text(title, style: const TextStyle(fontWeight: FontWeight.bold, color: deepGreen)),
      subtitle: Text(subtitle, style: const TextStyle(height: 1.5)),
      trailing: const Icon(Icons.chevron_left, color: green),
      onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('هذا القسم في النموذج الأولي، وسيُفعّل في مرحلة التطوير التالية.'))),
    ),
  );
}
